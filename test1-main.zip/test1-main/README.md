# Zajęcia z PSI
## Czego będziemy się uczyć?

***
**Będziemy się uczyć:**
1. HTML5
1. CSS
1. JS
1. inne
    - Git
